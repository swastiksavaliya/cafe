<!DOCTYPE html>
<html>
<head>
    <title>Home (cafe managment system)</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="img/LogoImage.jpg" type="img/icon" rel="icon">
</head>
<body>
    <div id="full">
        <div style="background-image: url('img/headerimg1.jpg'); width:100%;height:600px">
        <div id="header">
            <div id="logo">
                <h1><font color="white">Le Cafe</font></h1>
            </div>
            <div id="nav">
                <ul>
                    <li><a href="Home.php">Home</a></li>
                    <li><a href="Contect.php">Contect us</a></li>
                
                    <li><a href="bill.php">bill</a></li>
                    <li><a href="help.php">help</a></li>
                </ul>
            </div>
        </div>
         <div id="banner"></div>
        </div>
        <div id="f1">
           <center>
           <h3>Great Food Comes First<br>
Every day, more than 11 million guests visit Le cafe restaurants around the world. <br>
And they do so because our restaurants are known for serving high-quality, great-tasting,<br> and affordable food.
 Founded in 1954, Le cafe is the second largest fast food <br>hamburger chain in the world.
 The original Home of the Whopper, our commitment to <br>
 premium ingredients, signature recipes, and family-friendly dining<br>
  experiences is what has defined our brand for more than 50 successful years.</h3>

           
           </center>
        </div>
        <div id="welcome">
            <h1 align="center">Welcome to my project</h1>
        
</div>
<div id="g1">
    <div id="one"><img src="img/coffee.jpg" width="100%"></div>
    <div id="two"><img src="img/Masala_Paneer_Kathi_Roll.jpg" width="100%"></div>
    <div id="three"><img src="img/paneer pakora.jpg" width="100%"></div>
</div>
    </div>
</body>
</html>