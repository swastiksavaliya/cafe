
<!DOCTYPE html>
<html>
<head>
    
    <title>Le cafe</title>
    <link rel="stylesheet"type="text/css" href="bill.css">
  
   <style>
        h1{
            text-align: center;
	    
        }
    </style>   
</head>
<body class="body" bgcolor="gray">
<div>
<b>
<h2 style="text-align: center;">le cafe</h2>
<div class="container-fluid">
    <div class="container">
        <div class="part1">
            <fieldset>
                <legend>Personal Information</legend>
                Full Name: <input type="text" id="name"> <br>

                Your Email: <input type="text" id="email">
            </fieldset>
        </div>


        <div class="part2">
            <fieldset>
                <legend>Your Orders</legend>
               <p> Coffee (Rs. 100): <input type="text" id="Coffee"></p>
                <p>Pizza (Rs. 150): <input type="text" id="Pizza"></p>
                <p>Tacos (Rs. 180): <input type="text" id="Tacos"></p>
               <p> Cafe_special (Rs. 250): <input type="text" id="Cafe_special"></p>
            </fieldset>
        </div>
        
    </div>
    </b>
    <div class="container">
        <fieldset>
            <legend><b>Your Bill</b></legend>
            <h3>Your Name: <span id="name2"></span></h3>
            <h3>Email: <span id="email2"></span></h3>
            <table border="1" >
                <thead>
                    <tr><th>Menu</th><th>Price</th><th>Quantity</th><th>Amout</th></tr>
                </thead>
                <tbody id="bill">
                    <!-- <tr><td>Coffee</td><td>Rs. 100</td><td>1</td><td>100x1 = 100</td></tr> -->
                </tbody>		

                

            </table>
            </fieldset>
            <h1>Total Amout: Rs. <span id="amount">0</span></h1>
            
    </div>
</div>
<script>
var Coffee = 100, Pizza = 150, Tacos = 180, Cafe_special = 250;
var Coffee_q=0, Pizza_q=0, Tacos_q=0, Cafe_special_q=0;
var name = "", email="";
var CoffeeBill="",PizzaBill="",TacosBill="",Cafe_specialBill="";
var total_amount=0;

document.getElementById("name").addEventListener("keyup",function(){
    
    document.getElementById("name2").innerHTML=this.value;
});

document.getElementById("email").addEventListener("keyup",function(){
    
    document.getElementById("email2").innerHTML=this.value;
});



document.getElementById("Coffee").addEventListener("keyup",function(){
if(this.value==""||this.value==0){
    CoffeeBill="";
    Coffee_q=0;
    showBill();
}else{
    Coffee_q=this.value;
    CoffeeBill="<tr><td>Coffee</td><td>Rs. "+Coffee+"</td><td>"+Coffee_q+"</td><td>"+Coffee+"x"+Coffee_q+" = "+Coffee*Coffee_q+"</td></tr>";
    showBill();

}
});

document.getElementById("Pizza").addEventListener("keyup",function(){
if(this.value==""||this.value==0){
    PizzaBill="";
    Pizza_q=0;
    showBill();

}else{
    Pizza_q=this.value;
    PizzaBill="<tr><td>Pizza</td><td>Rs. "+Pizza+"</td><td>"+Pizza_q+"</td><td>"+Pizza+"x"+Pizza_q+" = "+Pizza*Pizza_q+"</td></tr>";
    showBill();
}
});

document.getElementById("Tacos").addEventListener("keyup",function(){
if(this.value==""||this.value==0){
    TacosBill="";
    Tacos_q=0;
    showBill();

}else{
    Tacos_q=this.value;
    TacosBill="<tr><td>Tacos</td><td>Rs. "+Tacos+"</td><td>"+Tacos_q+"</td><td>"+Tacos+"x"+Tacos_q+" = "+Tacos*Tacos_q+"</td></tr>";
    showBill();
}
});

document.getElementById("Cafe_special").addEventListener("keyup",function(){
if(this.value==""||this.value==0){
    Cafe_specialBill="";
    Cafe_special_q=0;
    showBill();

}else{
    Cafe_special_q=this.value;
    Cafe_specialBill="<tr><td>Cafe_special</td><td>Rs. "+Cafe_special+"</td><td>"+Cafe_special_q+"</td><td>"+Cafe_special+"x"+Cafe_special_q+" = "+Cafe_special*Cafe_special_q+"</td></tr>";
    showBill();
}
});


function showBill(){
    document.getElementById("bill").innerHTML=CoffeeBill+PizzaBill+TacosBill+Cafe_specialBill; //table statement
    document.getElementById("amount").innerHTML = Coffee*Coffee_q+Pizza*Pizza_q+Tacos*Tacos_q+Cafe_special*Cafe_special_q; // total amount
}
</script>
</body>
</html>
