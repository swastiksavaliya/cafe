<?php

session_start();


$host="localhost";

$user="root";

$password="";

$db="cafe database";


$data=mysqli_connect($host,$user,$password,$db);

if($data===false)
{
    die("connection error");
}

    if(isset($_POST['apply']))

    {
        $data_fname=$_POST['fname'];
        $data_lname=$_POST['lname'];
        $data_email=$_POST['email'];
        $data_phone=$_POST['phone'];
        $data_opinions=$_POST['opinions'];

        $sql="INSERT INTO contect(fname,lname,email,phone,opinions)
        VALUES(' $data_fname',' $data_lname','$data_email',' $data_phone','$data_opinions')";

        $result=mysqli_query($data,$sql);

        if($result)
        {
            $_SESSION['massage']="your aplication sent successsful";

            header("location:contect.php");
        }

        else
        {
            echo "Apply faild";
        }
    }


?>