




<!DOCTYPE html>
<html>
<head>
    <title>Home (cafe managment system)</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="img/LogoImage.jpg" type="img/icon" rel="icon">
</head>
<body>
    <div id="full">
        <div id="bg" style="background-image: url('img/home.jpg'); height=1200px;">
        <div id="header">
            <div id="logo">
                <h1><font color="black">Le Cafe</font></h1>
            </div>
            <div id="nav">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Contect us</a></li>
                    <li><a href="#">Menu</a></li>
                    <li><a href="#">bill</a></li>
                    <li><a href="#">help</a></li>
                </ul>
            </div>
        </div>
         <div id="banner"></div>
         <div id="form">
            <table style="color: yello;">
                <tr>
                    <td>id</td>
                    <td><input type="text" name="name" placeholder="Enter id" title="id"></td>    
                </tr>
                <tr>
                    <td>Coustmer Name</td>
                    <td><input type="text" name="name" placeholder="Enter name" title="name"></td>
                </tr>
                <tr>
                    <td>Item Name</td>
                    <td><input type="text" name="name" placeholder="Itme name" title="name"></td>
                </tr>
                <tr>
                    <td>Item price</td>
                    <td><input type="text" name="name" placeholder="Item Price" title="name"></td>
                </tr>
                <tr>
                    <td>Total amount</td>
                    <td><input type="text" name="name" placeholder="Total amount" title="name"></td>
                </tr>
                <tr>
                    <td><input style="width: 120px height: 30px; "type="submit" name="submit" value="submit"></td>
                </tr>
</table>
        </div>
        </div>
       
    </div>
</body>
</html>