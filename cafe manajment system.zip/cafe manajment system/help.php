<html>
<head>
<title> Le cafe </title>
</head>
<body bgcolor="gray">


    <h1>Help</h1>

<h3><p>Effective as of November 27, 2022</p></h3>
<br>
<br>
<h3><p>Privacy Policy Highlights
    
         This summary provides the highlights of our policy, but please click here to review the policy in full.
    </p></h3>
<br>
<br>
<h3><p>Information We Collect<br>

    We collect various types of information about our users in connection with the Services, including:
    
    Information you provide to us;<br>
    Information we collect about your use of our Services;<br>
    Information about your use of the Services; and<br>
    Information we obtain from third-party sources.<br>
    We also may collect information in ways that we describe to you at the point of <br>collection or otherwise with your consent
    </p></h3><br>
    <br>
    <h3><p>How We Use Information<br>
        We use the information we collect to, among other things:<br>
        
        Register and create your account;<br>
        Operate and manage our stored-value card program;<br>
        Provide and manage the products and Services you request;<br>
        Communicate with you about our products, services, and promotions;<br>
        Deliver targeted advertising, promotions, and offers; and<br>
        Understand our customers so that we can develop and <br>improve our customer service, promotions, products, and Services.
        We may otherwise use your information with your consent or at your direction.
        </p></h3><br><br>